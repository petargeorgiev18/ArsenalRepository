﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luxor.Data.Configuration
{
    public class Connection
    {
        public const string connectionString = "Server=DESKTOP-VI3C6PQ\\SQLEXPRESS;Database=LuxorDb;TrustServerCertificate=True;Trusted_Connection=True";
    }
}
