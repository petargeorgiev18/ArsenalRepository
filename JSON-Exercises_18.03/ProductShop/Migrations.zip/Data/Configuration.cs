﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=ProductShop;Integrated Security=True";
    }
}
